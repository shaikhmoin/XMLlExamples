//
//  ViewController.swift
//  XMLExample
//
//  Created by Akash on 9/8/18.
//  Copyright © 2018 Moin. All rights reserved.
//

import UIKit
import SwiftyXMLParser

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        let myString = "<DocumentElement><dtInvoiceTitleText><TitleType>1</TitleType><TitleName>InvoiceTitle</TitleName><TitleNameValue>DINE IN INVOICE</TitleNameValue><FontName>Century Gothic</FontName><FontSize>12</FontSize><FontStyle>Bold</FontStyle><IsPerticular>0</IsPerticular><WidthPercentage>0</WidthPercentage></dtInvoiceTitleText><dtInvoiceTitleText><TitleType>1</TitleType><TitleName>ParticularTitle</TitleName><TitleNameValue /><FontName>Century Gothic</FontName><FontSize>8</FontSize><FontStyle>Regular</FontStyle><IsPerticular>0</IsPerticular><WidthPercentage>0</WidthPercentage></dtInvoiceTitleText>"
        let xml1 = try! XML.parse(myString)

        if let text1 = xml1["DocumentElement", "dtInvoiceTitleText",0,"TitleType"].text {
            print(text1)
        }
        if let text2 = xml1["DocumentElement", "dtInvoiceTitleText",1,"TitleType"].text {
            print(text2)
        }
        if let text3 = xml1["DocumentElement", "dtInvoiceTitleText",0,"TitleName"].text {
            print(text3)
        }
        if let text4 = xml1["DocumentElement", "dtInvoiceTitleText",1,"TitleName"].text {
            print(text4)
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

