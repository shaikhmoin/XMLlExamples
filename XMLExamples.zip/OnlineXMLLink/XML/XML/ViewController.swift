//
//  ViewController.swift
//  XML
//
//  Created by MACOS on 6/15/17.
//  Copyright © 2017 MACOS. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate,XMLParserDelegate {

    var arr = [Any]()
    var brr = [String]()
    var str = ""
    
    @IBOutlet weak var tbl: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tbl.dataSource = self
        tbl.delegate = self
        
        let url = URL(string: "https://www.w3schools.com/xml/note.xml")
        
        //<note>
        //<to>Tove</to>
        //<from>Jani</from>
        //<heading>Reminder</heading>
        //<body>Don't forget me this weekend!</body>
        //</note>
        
        do
        {
            let dt = try Data(contentsOf: url!)
            
            let xml = XMLParser(data: dt)
            xml.delegate = self
            xml.parse()
        }
        catch
        {
            
        }
    }
    
    func parserDidStartDocument(_ parser: XMLParser) {
        arr = [Any]()
    }
    
    func parserDidEndDocument(_ parser: XMLParser) {
        print(arr)
        
    }
    
//    <note>
//    <to>Tove</to>
//    <from>Jani</from>
//    <heading>Reminder</heading>
//    <body>Don't forget me this weekend!</body>
//    </note>
    
    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String] = [:]) {
         if elementName == "note"
         {
            brr = [String]()
        }
    }
    
    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?) {
        if elementName == "to" ||
        elementName == "from" ||
        elementName == "heading"
        {
            brr.append(str)
        }
        else if(elementName == "note")
        {
            arr.append(brr)
        }
    }
    
    func parser(_ parser: XMLParser, foundCharacters string: String) {
        str = string
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        
        let dicfinal = arr[indexPath.row] as! [String]
        
        cell?.textLabel?.text = dicfinal[2] as! String?
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        let nav = self.storyboard?.instantiateViewController(withIdentifier: "next") as! First
//        
//        let dicfinal = arr[indexPath.row] as! [String]
//        nav.st = dicfinal[1]
//        self.navigationController?.pushViewController(nav, animated: true)
    }
}

