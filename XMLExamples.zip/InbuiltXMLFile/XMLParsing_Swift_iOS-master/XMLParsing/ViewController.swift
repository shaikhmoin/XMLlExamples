//
//  ViewController.swift
//  XMLParsing
//
//  Created by Nimblechapps - iOS on 30/08/17.
//  Copyright © 2017 Nimblechapps. All rights reserved.
//

import UIKit

class ViewController: UIViewController, XMLParserDelegate,UITableViewDataSource,UITableViewDelegate {
    
    var ipAddr:String = ""
    var countryCode:String = ""
    var countryName:String = ""
    var latitude:String = ""
    var longitude:String = ""
    
    var currentParsingElement:String = ""
    
    @IBOutlet weak var ipAddressLabel:UILabel!
    @IBOutlet weak var countryCodeLabel:UILabel!
    @IBOutlet weak var countryNameLabel:UILabel!
    @IBOutlet weak var latitudeLabel:UILabel!
    @IBOutlet weak var longitudeLabel:UILabel!

    @IBOutlet weak var tbl: UITableView!
    class Book {
        var bookTitle: String = String()
        var bookAuthor: String = String()
    }
    
    var books: [Book] = []
    var eName: String = String()
    var bookTitle = String()
    var bookAuthor = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        getXMLDataFromServer()
        tbl.dataSource = self
        tbl.delegate = self
    }

    //MARK:- Custom methods
    func getXMLDataFromServer(){
        
        if let path = Bundle.main.url(forResource: "book", withExtension: "xml") {
            if let parser = XMLParser(contentsOf: path) {
                parser.delegate = self
                parser.parse()
            }
        }
    }
    
    func displayOnUI(){
//        ipAddressLabel.text = ipAddr
//        countryCodeLabel.text = countryCode
//        countryNameLabel.text = countryName
//        latitudeLabel.text = latitude
//        longitudeLabel.text = longitude
    }
    
    //MARK:- XML Delegate methods
    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String] = [:]) {

        eName = elementName
        if elementName == "dtLogoSetting" {
            bookTitle = String()
            bookAuthor = String()
        }
    }
    
    func parser(_ parser: XMLParser, foundCharacters string: String) {
        let foundedChar = string.trimmingCharacters(in:NSCharacterSet.whitespacesAndNewlines)

        if (!foundedChar.isEmpty) {
            if eName == "LogoHeight" {
                bookTitle += foundedChar
            } else if eName == "LogoWidth" {
                bookAuthor += foundedChar
            }
        }
        
    }
    
    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?) {

        if elementName == "dtLogoSetting" {
            
            let book = Book()
            book.bookTitle = bookTitle
            book.bookAuthor = bookAuthor
            
            books.append(book)
        }
        print(books.count)
        print(books)
    }
    
    func parserDidEndDocument(_ parser: XMLParser) {
        DispatchQueue.main.async {
            // Update UI
            //self.displayOnUI()
        }
    }
    
    func parser(_ parser: XMLParser, parseErrorOccurred parseError: Error) {
        print("parseErrorOccurred: \(parseError)")
    }

    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return books.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        let book = books[indexPath.row]
        
        cell.textLabel?.text = book.bookTitle
        cell.detailTextLabel?.text = book.bookAuthor
        
        return cell
    }
}

